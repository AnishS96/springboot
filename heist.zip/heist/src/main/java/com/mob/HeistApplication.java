package com.mob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HeistApplication {

	public static void main(String[] args) {
		SpringApplication.run(HeistApplication.class, args);
	}

}
