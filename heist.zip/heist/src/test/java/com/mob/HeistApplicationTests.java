package com.mob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeistApplicationTests {

	@Test
	void contextLoads() {
	}

}
