package com.mob.test;



import java.io.FileInputStream;
import java.util.Map;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/new/")
public class Init {
//	Properties prop;
//	@Value("${fpath}")
//	private String fpath;
			@Autowired Controller object;
		@RequestMapping(value="test",method=RequestMethod.GET)
		public ResponseEntity<?>test(@RequestParam  Map<String,String> mapping){
			int value = 0;
			Logger log = LogManager.getLogger("heist");
			try {
	System.out.println(mapping);
	
	log.debug("testAPI started: " + mapping);
	log.info("testAPI started: " + mapping);
	String	operation=	mapping.get("object").toString();
	int a=Integer.parseInt(mapping.get("a").toString());
	int b=Integer.parseInt(mapping.get("b").toString());


		switch(operation) {
		case "add":
				value=object.add(a,b);
				break;
			case "sub":
				value=object.sub(a,b);
				break;
			case "mul":
				value=object.mul(a,b);
				break;
			case "div":
				value=object.div(a,b);
				break;
				
			}
	
			}
		catch(Exception e) {
			
			e.printStackTrace();
		}

		return new ResponseEntity<>(mapping,HttpStatus.OK);

	}
		
//		@RequestMapping(value="load_property",method=RequestMethod.GET)
//		public ResponseEntity<?>load_property(@RequestParam  Map<String,String> map){	
//		System.out.println("load_property: "+fpath);
//		
//
//			try {
//			
//				
//				FileInputStream f=new FileInputStream(fpath);
//				Properties prop= new Properties();
//				prop.load(f);
//				
//			}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//			System.out.println("ended :"+fpath);
//		return new ResponseEntity<>(prop,HttpStatus.OK);
//		
//}
}